      </div> <!-- /page-wrapper -->
    </div> <!-- /mainContent -->
<!-- CLEAN </div> -->
		<footer><p><i class="fas fa-copyright"></i> 2021 <a href="http://rmbinformatica.com" target="_blank">RMB Informática</a> <a href="https://github.com/rmbinformatica/controle-estoque" target="_blank"><i class="fab fa-github"></i></a> | <i class="fas fa-code-branch"></i> <?= VERSAO ?> | <i class="fas fa-database"></i> <?= BANCO ?> | <i class="fas fa-clock"></i> <?= NOW ?></p></footer>
	</section>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/barra_superior_v1_04.js"></script>
</body>
</html>
<?php
?>