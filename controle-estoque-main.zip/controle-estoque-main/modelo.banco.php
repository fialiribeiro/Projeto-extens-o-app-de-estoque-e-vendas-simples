<?php
/*
Arquivo modelo do arquivo de configuracao do banco de dados.
Configure conforme as credenciais de acesso ao seu mysql.
Renomeie o arquivo para banco.php
*/

date_default_timezone_set('America/Recife');
define('SERVIDOR','localhost');
define('USUARIO','usuario_mysql');
define('SENHA','senha_mysql');
define('BANCO','nome_bancodados');
define('NOW',date("Y-m-d H:i:s"));
define('HOJE',date("Y-m-d"));
?>
